package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"os"

	"gopkg.in/yaml.v3"
)

type Permissions []struct {
	ServiceAccountName string `yaml:"serviceAccountName"`
	Rules              []struct {
		ApiGroups []string `yaml:"apiGroups"`
		Resources []string `yaml:"resources"`
		Verbs     []string `yaml:"verbs"`
	} `yaml:"rules"`
}

func main() {
	if len(os.Args) < 3 {
		log.Fatal("Usage: go run merge-yaml.go <file1.yaml> <file2.yaml>")
	}

	// Read in the first YAML file
	file1, err := ioutil.ReadFile(os.Args[1])
	if err != nil {
		log.Fatalf("Error reading %s: %v", os.Args[1], err)
	}

	// Unmarshal the first YAML file into a map[string]interface{}
	var data1 map[string]interface{}
	if err := yaml.Unmarshal(file1, &data1); err != nil {
		log.Fatalf("Error unmarshalling %s: %v", os.Args[1], err)
	}

	// Read in the second YAML file
	file2, err := ioutil.ReadFile(os.Args[2])
	if err != nil {
		log.Fatalf("Error reading %s: %v", os.Args[2], err)
	}

	// Unmarshal the second YAML file into a map[string]interface{}
	var data2 map[string]interface{}
	if err := yaml.Unmarshal(file2, &data2); err != nil {
		log.Fatalf("Error unmarshalling %s: %v", os.Args[2], err)
	}

	// Merge the two maps
	mergeMaps(data1, data2)

	permissions := Permissions{}
	man := data1["spec"].(map[string]interface{})["install"].(map[string]interface{})["spec"].(map[string]interface{})["clusterPermissions"]
	permissionsBytes, err := yaml.Marshal(man)
	if err != nil {
		log.Fatalf("Error marshalling permissions: %v", err)
	}
	if err := yaml.Unmarshal(permissionsBytes, &permissions); err != nil {
		log.Fatalf("Error unmarshalling permissions: %v", err)
	}

	for j, cp := range permissions {
		if cp.ServiceAccountName == "ndb-operator-app-sa" {
			for i, rule := range cp.Rules {
				for _, apiGroup := range rule.ApiGroups {
					if apiGroup == "policy" {
						for _, resources := range rule.Resources {
							if resources == "poddisruptionbudgets" {
								rule.Resources = append(rule.Resources, "poddisruptionbudgets/finalizers.v1")
								permissions[j].Rules[i] = rule
							}
						}
					} else if apiGroup == "mysql.oracle.com" {
						for _, resources := range rule.Resources {
							if resources == "ndbclusters" {
								rule.Resources = append(rule.Resources, "ndbclusters/finalizers")
								permissions[j].Rules[i] = rule
							}
						}
					}
				}
			}
			break
		}
	}

	// Iterate over the rules and find the apiGroups with name "policy"

	data1["spec"].(map[string]interface{})["install"].(map[string]interface{})["spec"].(map[string]interface{})["clusterPermissions"] = permissions

	// Marshal the merged data back into YAML
	outData, err := yaml.Marshal(data1)
	if err != nil {
		log.Fatalf("Error marshalling merged data: %v", err)
	}

	// Write the merged data back to the first YAML file
	if err := ioutil.WriteFile(os.Args[1], outData, os.ModePerm); err != nil {
		log.Fatalf("Error writing merged data to %s: %v", os.Args[1], err)
	}

	fmt.Printf("Merged data written to %s\n", os.Args[1])

}

var yaml_path string

// Merge two maps by adding all fields from the second map to the first map
func mergeMaps(dest, src map[string]interface{}) {

	for k, v := range src {

		/*if (yaml_path + "/" + k) == "/spec/install/spec/clusterPermissions" {

		} else {*/
		if _, ok := dest[k]; ok {
			if subMap, ok := v.(map[string]interface{}); ok {
				if destSubMap, ok := dest[k].(map[string]interface{}); ok {
					old_path := yaml_path
					yaml_path = yaml_path + "/" + k
					mergeMaps(destSubMap, subMap)
					yaml_path = old_path
					continue
				}
			}
		}
		dest[k] = v
		//}
	}
}
